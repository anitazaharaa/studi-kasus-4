#include <iostream>
#include <fstream>
#include "../library/output.h"

int main(){
  Output output;
  output.getData();
  Output.toFile();
  return 0;
}