#include <iostream>
#include <fstream>
using namespace std;

class Input{
  public :
        void cetak(){
          cout <<"Data Pengeluaran andi \n";
          cout <<"========================== \n";
          cout <<"input untuk berapa bulan? : "; 
          cin>>bulan;
          cout <<" Uang Kuliah              : "; 
          cin>>kuliah;
          cout <<" Uang Saku               : "; 
          cin>>jajan;
          cout <<" Uang Ditabung            : ";                cin>>tabung;
        }
  void getData(){
    tulis_data.open("../data/input.txt");
    tulis_data<<bulan<<endl;
    tulis_data<<kuliah<<endl;
    tulis_data<<jajan<<endl;
    tulis_data<<tabung;
    tulis_data.close();
  }
private :
  ofstream tulis_data;
  int bulan;
  int kuliah;
  int jajan;
  int tabung;
};