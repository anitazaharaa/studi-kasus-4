#include<iostream>
#include<fstream>
#include"library/input.h"
#include"library/proses.h"
#include"library/output.h"
using namespace std;
int main(){
  Input input;
	input.cetak();
	input.getData();
  
  Proses proses;
	proses.getdata();
	proses.toFile();
  
  Output output;
	output.cetak();
	output.getData();
  return 0;
}