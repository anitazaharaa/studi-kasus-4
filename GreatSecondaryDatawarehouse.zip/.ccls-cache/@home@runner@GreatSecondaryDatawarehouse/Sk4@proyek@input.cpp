#include<iostream>
#include<fstream>
#include"../library/input.h"
int main(){
	Input tes;
	tes.cetak();
	tes.getData();
}