using namespace std;
class Proses{
public :
void getdata(){
  ambil_data.open("../pradata/input.txt");
  while(!ambil_data.eof()){
  ambil_data>>bulan;
  ambil_data>>kuliah;
  ambil_data>>jajan;
  ambil_data>>tabung;
  }
  ambil_data.close();
  }
void toFile(){
  int total = kuliah+jajan+tabung;
  int tabungan = tabung*bulan;
  int sisa = tabungan-total;

  tulis_data.open("../pradata/proses.txt");
  tulis_data<<total<<endl;
  tulis_data<<tabungan<<endl;
  tulis_data<<sisa;
  tulis_data.close();
}
private :
ifstream ambil_data;
ofstream tulis_data;
int bulan;
int kuliah;
int jajan;
int tabung;
};