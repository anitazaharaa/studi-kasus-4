#include<iostream>
#include<fstream>
#include"../library/proses.h"
int main(){
	Proses proses;
  proses.getdata();
	proses.toFile();
  return 0;
}